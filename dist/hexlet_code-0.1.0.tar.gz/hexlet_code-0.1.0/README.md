### Hexlet tests and linter status:
[![Actions Status](https://github.com/oldchap-cpu/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/oldchap-cpu/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/0ebac768fd5a6f9995e5/maintainability)](https://codeclimate.com/github/oldchap-cpu/python-project-49/maintainability)
